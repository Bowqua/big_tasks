﻿import argparse
from dns_core.cache import Cache
from dns_core.resolver import IterativeResolver
from dns_core.server import DNSServer

def main():
    parser = argparse.ArgumentParser(description='Iterative DNS resolver server')
    parser.add_argument("--listen", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=5353)
    parser.add_argument("--cache", default="dns_cache.sqlite")
    parser.add_argument("--timeout", type=float, default=3.5)
    args = parser.parse_args()

    cache = Cache(args.cache)
    resolver = IterativeResolver(cache=cache, timeout=args.timeout)
    server = DNSServer(args.listen, args.port, resolver)
    server.start()


if __name__ == "__main__":
    main()
