﻿from typing import Tuple

def encode_name(name: str) -> bytes:
    name = name.rstrip(".")
    if not name:
        return b"\x00"

    parts = name.split(".")
    out = bytearray()
    for p in parts:
        b = p.encode("utf-8")
        if len(b) > 63:
            raise ValueError("Label too long")

        out.append(len(b))
        out.extend(b)
    out.append(0)

    return bytes(out)


def decode_name(buf: bytes, offset: int) -> Tuple[str, int]:
    labels = []
    i = offset
    jumped = False
    jumped_end = 0

    while True:
        if i >= len(buf):
            raise ValueError("Bad name")

        length = buf[i]
        if length & 0xC0 == 0xC0:
            if i + 1 >= len(buf):
                raise ValueError("Bad pointer")

            ptr = ((length & 0x3F) << 8) | buf[i + 1]
            if not jumped:
                jumped_end = i + 2
                jumped = True

            i = ptr
            continue

        if length == 0:
            i += 1
            break

        i += 1
        label = buf[i:i+length]
        i += length
        labels.append(label.decode("utf-8"))

    name = ".".join(labels) + "."

    return name, (jumped and jumped_end or i)
