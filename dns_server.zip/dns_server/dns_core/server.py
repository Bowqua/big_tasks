﻿import socket, struct, threading, time
from typing import Optional
from .message import DNSMessage
from .constants import CLASS_IN

class DNSServer:
    def __init__(self, host: str, port: int, resolver):
        self.host = host
        self.port = port
        self.resolver = resolver
        self._udp_sock: Optional[socket.socket] = None
        self._tcp_sock: Optional[socket.socket] = None
        self._stop = threading.Event()


    def start(self):
        self._udp_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self._udp_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self._udp_sock.bind((self.host, self.port))

        self._tcp_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._tcp_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self._tcp_sock.bind((self.host, self.port))
        self._tcp_sock.listen(50)

        threading.Thread(target=self.serve_udp, daemon=True).start()
        threading.Thread(target=self.serve_tcp, daemon=True).start()

        print(f"DNS iterative resolver listening on {self.host}:{self.port} (UDP/TCP)")
        try:
            while not self._stop.is_set():
                time.sleep(0.3)
        except KeyboardInterrupt:
            pass
        finally:
            self.stop()


    def stop(self):
        self._stop.set()
        for s in (self._udp_sock, self._tcp_sock):
            try:
                if s:
                    s.close()
            except Exception:
                pass


    def serve_udp(self):
        sock = self._udp_sock
        while not self._stop.is_set():
            try:
                data, addr = sock.recvfrom(4096)
            except Exception:
                break
            threading.Thread(target=self.handle_udp_request, args=(data, addr), daemon=True).start()


    def handle_udp_request(self, data, addr):
        req = None
        try:
            req = DNSMessage.parse(data)
            if not req.qd:
                return
            qname, qtype, qclass = req.qd[0]
            if qclass != CLASS_IN:
                self.send_error_udp(req, addr, rcode=4)  # NOTIMP
                return

            resp = self.resolver.resolve(qname.rstrip("."), qtype)
            resp.id = req.id
            rd = req.flags & 0x0100
            resp.flags = (resp.flags & 0xFFF0) | rd | 0x8000 | 0x0080  # QR, RD(copy), RA
            wire = resp.build()

            if len(wire) > 512:
                short = DNSMessage()
                short.id = req.id
                short.flags = 0x8000 | 0x0200 | rd | 0x0080
                short.qd = req.qd
                wire = short.build()

            self._udp_sock.sendto(wire, addr)
        except Exception:
                self.send_error_udp(req, addr, rcode=2)


    def send_error_udp(self, req: Optional[DNSMessage], addr, rcode: int):
        resp = DNSMessage()
        resp.id = req.id if req else 0
        resp.flags = 0x8000 | (rcode & 0xF) | 0x0080
        resp.qd = req.qd if req else []
        self._udp_sock.sendto(resp.build(), addr)


    def serve_tcp(self):
        sock = self._tcp_sock
        while not self._stop.is_set():
            try:
                conn, addr = sock.accept()
            except Exception:
                break
            threading.Thread(target=self.handle_tcp_conn, args=(conn, addr), daemon=True).start()


    def handle_tcp_conn(self, conn: socket.socket, addr):
        with conn:
            conn.settimeout(10.0)
            try:
                hl = conn.recv(2)
                if len(hl) < 2:
                    return

                L = struct.unpack("!H", hl)[0]
                buf = b""
                while len(buf) < L:
                    chunk = conn.recv(L - len(buf))
                    if not chunk:
                        return
                    buf += chunk

                req = DNSMessage.parse(buf)
                if not req.qd:
                    return

                qname, qtype, qclass = req.qd[0]
                if qclass != CLASS_IN:
                    resp = DNSMessage()
                    resp.id = req.id
                    resp.flags = 0x8000 | 0x0080 | 4
                    resp.qd = req.qd
                    out = resp.build()
                    conn.sendall(struct.pack("!H", len(out)) + out)
                    return

                resp = self.resolver.resolve(qname.rstrip("."), qtype)
                resp.id = req.id
                rd = req.flags & 0x0100
                resp.flags = (resp.flags & 0xFFF0) | rd | 0x8000 | 0x0080
                wire = resp.build()
                conn.sendall(struct.pack("!H", len(wire)) + wire)

            except Exception:
                try:
                    resp = DNSMessage()
                    resp.id = 0
                    resp.flags = 0x8000 | 0x0080 | 2
                    out = resp.build()
                    conn.sendall(struct.pack("!H", len(out)) + out)
                except Exception:
                    pass
