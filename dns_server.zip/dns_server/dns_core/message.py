﻿import socket, struct
from typing import List, Tuple, Dict, Any
from .constants import REV_QTYPE_MAP
from .names import encode_name, decode_name

class DNSMessage:
    def __init__(self):
        self.id = 0
        self.flags = 0
        self.qd: List[Tuple[str, int, int]] = []
        self.an: List[Dict[str, Any]] = []
        self.ns: List[Dict[str, Any]] = []
        self.ar: List[Dict[str, Any]] = []

    @staticmethod
    def parse(data: bytes) -> "DNSMessage":
        if len(data) < 12:
            raise ValueError("short header")
        msg = DNSMessage()
        (msg.id, msg.flags, qdcount, ancount, nscount, arcount) = struct.unpack("!HHHHHH", data[:12])
        ofs = 12


        def parse_q():
            nonlocal ofs
            qname, ofs = decode_name(data, ofs)
            qtype, qclass = struct.unpack("!HH", data[ofs:ofs+4])
            ofs += 4

            return qname, qtype, qclass


        def parse_rr():
            nonlocal ofs
            name, ofs = decode_name(data, ofs)
            rtype, rclass, ttl, rdlength = struct.unpack("!HHIH", data[ofs:ofs+10])
            ofs += 10
            rdata = data[ofs:ofs+rdlength]
            ofs += rdlength

            return {"name": name, "type": rtype, "class": rclass, "ttl": ttl, "rdata": rdata}


        for _ in range(qdcount):
            msg.qd.append(parse_q())
        for _ in range(ancount):
            msg.an.append(parse_rr())
        for _ in range(nscount):
            msg.ns.append(parse_rr())
        for _ in range(arcount):
            msg.ar.append(parse_rr())
        return msg


    def build(self) -> bytes:
        parts = [struct.pack("!HHHHHH", self.id, self.flags,
                             len(self.qd), len(self.an), len(self.ns), len(self.ar))]

        for (qname, qtype, qclass) in self.qd:
            parts.append(encode_name(qname))
            parts.append(struct.pack("!HH", qtype, qclass))


        def emit_rr(rr):
            parts.append(encode_name(rr["name"]))
            parts.append(struct.pack("!HHI", rr["type"], rr["class"], max(0, int(rr["ttl"]))))
            rdata = rr["rdata"]
            parts.append(struct.pack("!H", len(rdata)))
            parts.append(rdata)

        for rr in self.an: parts.append(b"") or emit_rr(rr)
        for rr in self.ns: parts.append(b"") or emit_rr(rr)
        for rr in self.ar: parts.append(b"") or emit_rr(rr)

        return b"".join(parts)


def rdata_to_text(rr: Dict[str, Any]) -> str:
    t = rr["type"]; r = rr["rdata"]
    if t == 1:
        return socket.inet_ntoa(r)

    if t == 28:
        return socket.inet_ntop(socket.AF_INET6, r)

    if t in (REV_QTYPE_MAP["NS"], REV_QTYPE_MAP["CNAME"]):
        name, _ = decode_name(r, 0); return name

    if t == REV_QTYPE_MAP["MX"]:
        pref = struct.unpack("!H", r[:2])[0]
        name, _ = decode_name(r, 2)
        return f"{pref} {name}"

    return repr(r)
