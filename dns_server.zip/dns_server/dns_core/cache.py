﻿import sqlite3, time
from typing import List, Dict, Any
from .constants import CLASS_IN

class Cache:
    def __init__(self, path: str = "dns_cache.sqlite"):
        self.path = path
        self.init_db()


    def init_db(self):
        con = sqlite3.connect(self.path)
        with con:
            con.execute("""
            CREATE TABLE IF NOT EXISTS cache (
                name TEXT NOT NULL,
                type INTEGER NOT NULL,
                rdata BLOB NOT NULL,
                ttl INTEGER NOT NULL,
                expires_at INTEGER NOT NULL,
                PRIMARY KEY(name, type, rdata)
            )
            """)

        con.close()


    def put_rr(self, name: str, rtype: int, rdata: bytes, ttl: int):
        now = int(time.time())
        exp = now + max(0, int(ttl))
        con = sqlite3.connect(self.path)

        with con:
            con.execute("""
            INSERT OR REPLACE INTO cache(name, type, rdata, ttl, expires_at)
            VALUES (?, ?, ?, ?, ?)
            """, (name.lower(), rtype, sqlite3.Binary(rdata), ttl, exp))

        con.close()


    def get_rrs(self, name: str, rtype: int) -> List[Dict[str, Any]]:
        now = int(time.time())
        con = sqlite3.connect(self.path)
        cur = con.cursor()
        cur.execute("DELETE FROM cache WHERE expires_at < ?", (now,))
        con.commit()
        cur.execute("""
        SELECT name, type, rdata, ttl, expires_at FROM cache
        WHERE name = ? AND type = ? AND expires_at >= ?
        """, (name.lower(), rtype, now))
        rows = cur.fetchall()
        con.close()
        out = []

        for n, t, rdata, ttl, exp in rows:
            out.append({"name": n + ".", "type": t, "class": CLASS_IN, "ttl": exp - now, "rdata": rdata})

        return out


    def put_from_message(self, msg):
        for section in (msg.an, msg.ns, msg.ar):
            for rr in section:
                if rr["class"] != CLASS_IN:
                    continue

                ttl = max(0, min(rr["ttl"], 86400))
                try:
                    self.put_rr(rr["name"].lower().rstrip("."), rr["type"], rr["rdata"], ttl)
                except Exception:
                    pass
