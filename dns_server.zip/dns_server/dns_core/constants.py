﻿import socket

ROOT_SERVERS = [
    ("8.8.8.8", 53),
    ("1.1.1.1", 53),
]

QTYPE_MAP = {
    1: "A",
    2: "NS",
    5: "CNAME",
    6: "SOA",
    15: "MX",
    16: "TXT",
    28: "AAAA"
}

REV_QTYPE_MAP = {v: k for k, v in QTYPE_MAP.items()}
CLASS_IN = 1


def ip4_to_bytes(ip: str) -> bytes:
    return socket.inet_aton(ip)


def bytes_to_ip4(b: bytes) -> str:
    return socket.inet_ntoa(b)
