﻿import random, socket, struct
from typing import Tuple
from .message import DNSMessage

def dns_query_upstream(server: Tuple[str, int], qname: str, qtype: int, use_tcp: bool = False,
                       timeout=3.0, rd_flag=False) -> DNSMessage:
    msg = DNSMessage()
    msg.id = random.randint(0, 0xFFFF)
    flags = 0

    if rd_flag:
        flags |= 0x0100

    msg.flags = flags
    msg.qd = [(qname, qtype, 1)]
    wire = msg.build()

    if not use_tcp:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.settimeout(timeout)

        try:
            sock.sendto(wire, server)
            data, _ = sock.recvfrom(4096)
            return DNSMessage.parse(data)

        finally:
            sock.close()

    else:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(timeout)

        try:
            sock.connect(server)
            sock.sendall(struct.pack("!H", len(wire)) + wire)
            hdr = sock.recv(2)

            if len(hdr) < 2:
                raise IOError("short tcp len")

            l = struct.unpack("!H", hdr)[0]
            buf = b""

            while len(buf) < l:
                chunk = sock.recv(l - len(buf))
                if not chunk:
                    break
                buf += chunk

            return DNSMessage.parse(buf)

        finally:
            sock.close()


def retry_udp_then_tcp(server: Tuple[str, int], qname: str, qtype: int, timeout=3.0) -> DNSMessage:
    resp = dns_query_upstream(server, qname, qtype, use_tcp=False, timeout=timeout, rd_flag=False)
    tc = (resp.flags & 0x0200) != 0

    if tc:
        resp = dns_query_upstream(server, qname, qtype, use_tcp=True, timeout=timeout, rd_flag=False)

    return resp
