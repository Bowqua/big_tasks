﻿import random, socket
from typing import Optional, List, Dict, Any
from .constants import ROOT_SERVERS, CLASS_IN, REV_QTYPE_MAP
from .cache import Cache
from .message import DNSMessage
from .names import decode_name
from .upstream import retry_udp_then_tcp

class IterativeResolver:
    def __init__(self, cache: Cache, timeout=3.5, max_depth=20):
        self.cache = cache
        self.timeout = timeout
        self.max_depth = max_depth


    def resolve(self, qname: str, qtype: int) -> DNSMessage:
        cached = self.cache.get_rrs(qname, qtype)
        cname_cached = self.cache.get_rrs(qname, REV_QTYPE_MAP["CNAME"])
        if cached and not cname_cached:
            return self.build_response_from_cache(qname, qtype, cached)

        servers = list(ROOT_SERVERS)
        visited = set()
        depth = 0
        cname_chain_guard = 0
        current_qname = qname

        final_answer = DNSMessage()
        final_answer.id = 0
        final_answer.flags = 0x8000 | 0x0080  # QR, RA
        final_answer.qd = [(qname, qtype, CLASS_IN)]

        while depth < self.max_depth:
            depth += 1
            random.shuffle(servers)
            response = None

            for srv in servers:
                key = (srv[0], current_qname, qtype)
                if key in visited:
                    continue
                visited.add(key)
                try:
                    response = retry_udp_then_tcp(srv, current_qname, qtype, timeout=self.timeout)
                    self.cache.put_from_message(response)
                    break
                except Exception:
                    continue

            if response is None:
                break

            rcode = response.flags & 0x000F
            if rcode != 0:
                final_answer.flags |= rcode
                final_answer.ns = response.ns
                return final_answer

            if any(rr["type"] == qtype for rr in response.an):
                final_answer.an = response.an
                final_answer.ns = response.ns
                final_answer.ar = response.ar
                return final_answer

            cname_rrs = [rr for rr in response.an if rr["type"] == REV_QTYPE_MAP["CNAME"]]
            if cname_rrs:
                cname_chain_guard += 1
                if cname_chain_guard > 10:
                    return final_answer
                target, _ = decode_name(cname_rrs[0]["rdata"], 0)
                final_answer.an.extend(cname_rrs)
                current_qname = target.rstrip(".")
                continue

            ns_refs = [rr for rr in response.ns if rr["type"] == REV_QTYPE_MAP["NS"]]
            if ns_refs:
                glue_map: Dict[str, List[tuple]] = {}
                for rr in response.ar:
                    if rr["type"] == 1:
                        a_name = rr["name"].lower()
                        ip = socket.inet_ntoa(rr["rdata"])
                        glue_map.setdefault(a_name, []).append((ip, 53))

                new_servers: List[tuple] = []
                for rr in ns_refs:
                    ns_name, _ = decode_name(rr["rdata"], 0)
                    key = ns_name.lower()
                    if key in glue_map:
                        new_servers.extend(glue_map[key])
                    else:
                        a_cached = self.cache.get_rrs(ns_name.rstrip("."), 1)
                        if a_cached:
                            for a_rr in a_cached:
                                new_servers.append((socket.inet_ntoa(a_rr["rdata"]), 53))
                        else:
                            ns_ip = self.resolve_one_a(ns_name)
                            if ns_ip:
                                new_servers.append((ns_ip, 53))

                if new_servers:
                    servers = new_servers
                    continue

            cached = self.cache.get_rrs(current_qname, qtype)
            if cached:
                final_answer.an = cached
                return final_answer

            return final_answer

        return final_answer


    def resolve_one_a(self, host: str) -> Optional[str]:
        target_type = 1
        servers = list(ROOT_SERVERS)
        visited = set()
        current = host.rstrip(".")

        for _ in range(10):
            random.shuffle(servers)
            for srv in servers:
                key = (srv[0], current, target_type)
                if key in visited:
                    continue

                visited.add(key)
                try:
                    resp = retry_udp_then_tcp(srv, current, target_type, timeout=self.timeout)
                    self.cache.put_from_message(resp)
                except Exception:
                    continue

                for rr in resp.an:
                    if rr["type"] == 1 and rr["name"].lower().rstrip(".") == current.lower():
                        return socket.inet_ntoa(rr["rdata"])

                for rr in resp.an:
                    if rr["type"] == 5:
                        cname, _ = decode_name(rr["rdata"], 0)
                        current = cname.rstrip(".")
                        break

                ns_refs = [rr for rr in resp.ns if rr["type"] == 2]
                if ns_refs:
                    new_servers = []
                    glue = {}

                    for rr in resp.ar:
                        if rr["type"] == 1:
                            glue.setdefault(rr["name"].lower(), []).append(socket.inet_ntoa(rr["rdata"]))

                    for rr in ns_refs:
                        nsn, _ = decode_name(rr["rdata"], 0)
                        if nsn.lower() in glue:
                            for ip in glue[nsn.lower()]:
                                new_servers.append((ip, 53))
                        else:
                            a_cached = self.cache.get_rrs(nsn.rstrip("."), 1)
                            for a_rr in a_cached:
                                new_servers.append((socket.inet_ntoa(a_rr["rdata"]), 53))

                    if new_servers:
                        servers = new_servers
                        continue
        return None


    def build_response_from_cache(self, qname: str, qtype: int, rrs: List[Dict[str, Any]]) -> DNSMessage:
        msg = DNSMessage()
        msg.id = 0
        msg.flags = 0x8000 | 0x0080
        msg.qd = [(qname, qtype, CLASS_IN)]
        msg.an = rrs

        return msg
