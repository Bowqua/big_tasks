using NUnitLite;

namespace Delegates.TreeTraversal;

class Program
{
	static void Main(string[] args)
	{
		new AutoRun().Execute(args);
	}
}