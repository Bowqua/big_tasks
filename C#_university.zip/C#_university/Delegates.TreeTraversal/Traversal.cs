namespace Delegates.TreeTraversal;

public static class Traversal
{
	private static IEnumerable<TResult> TraverseLeaves<TNode, TResult>(
		TNode node,
		Func<TNode, IEnumerable<TNode>> getChildren, 
		Func<TNode, IEnumerable<TResult>> selectMany)
	{
		if (node == null)
			yield break;
		
		foreach (var item in selectMany(node))
			yield return item;
		
		foreach (var child in getChildren(node))
			foreach (var result in TraverseLeaves(child, getChildren, selectMany))
				yield return result;
	}
	
	public static IEnumerable<Product> GetProducts(ProductCategory root)
	{
		return TraverseLeaves(
			root,
			node => node.Categories,
			node => node.Products
		);
	}

	public static IEnumerable<Job> GetEndJobs(Job root)
	{
		return TraverseLeaves<Job, Job>(
			root,
			node => node.Subjobs,
			node =>
			{
				if (node.Subjobs == null || node.Subjobs.Count == 0)
					return [node];

				return [];
			}
		);
	}

	public static IEnumerable<T> GetBinaryTreeValues<T>(BinaryTree<T> root)
	{
		return TraverseLeaves<BinaryTree<T>, T>(
			root, 
			node => [node.Left, node.Right],
			node =>
			{
				if (node.Left == null && node.Right == null)
					return [node.Value];

				return [];
			});
	}
}