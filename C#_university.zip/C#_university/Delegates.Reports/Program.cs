using NUnitLite;

namespace Delegates.Reports;

class Program
{
	static void Main(string[] args)
	{
		new AutoRun().Execute(args);
	}
}