﻿using System.Globalization;
using System.Text;

namespace Delegates.Reports;

public class ReportMaker
{
	private readonly Func<string, string> makeCaption;
	private readonly Func<string, string, string> makeItem;
	private readonly Func<string> beginList;
	private readonly Func<string> endList;

	private ReportMaker(Func<string, string> makeCaption, Func<string, string, string> makeItem, 
		Func<string> beginList, Func<string> endList)
	{
		this.makeCaption = makeCaption;
		this.makeItem = makeItem;
		this.beginList = beginList;
		this.endList = endList;
	}
	
	public static ReportMaker CreateHtmlFormatter()
	{
		var caption = (string text) => $"<h1>{text}</h1>";;
		var item = (string name, string value) => $"<li><b>{name}</b>: {value}";
		var beginList = () => "<ul>";
		var endList = () => "</ul>";
		
		return new ReportMaker(caption, item, beginList, endList);
	}

	public static ReportMaker CreateMarkdownFormatter()
	{
		var caption = (string text) => $"## {text}\n\n";
		var item = (string name, string value) => $" * **{name}**: {value}\n\n";
		var beginList = () => "";
		var endList = () => "";
		
		return new ReportMaker(caption, item, beginList, endList);
	}

	public string CreateReport(string title,
		IEnumerable<(string name, IEnumerable<double> series)> series,
		Func<IEnumerable<double>, string> aggregator)
	{
		var result = new StringBuilder();
		result.Append(makeCaption(title));
		result.Append(beginList());

		foreach (var (name, sequence) in series)
		{
			var value = aggregator(sequence);
			result.Append(makeItem(name, value));
		}
		
		result.Append(endList());
		return result.ToString();
	}
}

public static class ReportMakerHelper
{	
	private static IEnumerable<(string name, IEnumerable<double> series)> BuildSeries(IEnumerable<Measurement> data) =>
		new[]
		{
			("Temperature", data.Select(m => m.Temperature)),
			("Humidity",    data.Select(m => m.Humidity))
		};
	
	private static string CalculateMeanStd(IEnumerable<double> sequence)
	{
		var list = sequence.ToList();
		var mean = list.Average();
		var std = Math.Sqrt(list.Select(z => Math.Pow(z - mean, 2)).Sum() / (list.Count - 1));
		
		return mean.ToString(CultureInfo.InvariantCulture) + "±" + std.ToString(CultureInfo.InvariantCulture);
	}
	
	private static string CalculateMedian(IEnumerable<double> sequence)
	{
		var list = sequence.OrderBy(z => z).ToList();
		return list.Count % 2 == 0 
			? ((list[list.Count / 2] + list[list.Count / 2 - 1]) / 2).ToString(CultureInfo.InvariantCulture) 
			: list[list.Count / 2].ToString(CultureInfo.InvariantCulture);
	}
	
	public static string MeanAndStdHtmlReport(IEnumerable<Measurement> data)
	{
		var formatter = ReportMaker.CreateHtmlFormatter();
		var series = BuildSeries(data);
		
		return formatter.CreateReport("Mean and Std", series, CalculateMeanStd);
	}

	public static string MedianMarkdownReport(IEnumerable<Measurement> data)
	{
		var formatter = ReportMaker.CreateMarkdownFormatter();
		var series = BuildSeries(data);
		
		return formatter.CreateReport("Median", series, CalculateMedian);
	}

	public static string MeanAndStdMarkdownReport(IEnumerable<Measurement> measurements)
	{
		var formatter = ReportMaker.CreateMarkdownFormatter();
		var series = BuildSeries(measurements);
		
		return formatter.CreateReport("Mean and Std", series, CalculateMeanStd);
	}

	public static string MedianHtmlReport(IEnumerable<Measurement> measurements)
	{
		var formatter = ReportMaker.CreateHtmlFormatter();
		var series = BuildSeries(measurements);
		
		return formatter.CreateReport("Median", series, CalculateMedian);
	}
}