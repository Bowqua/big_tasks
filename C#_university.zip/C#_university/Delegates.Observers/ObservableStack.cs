﻿using System.Text;

namespace Delegates.Observers;

public enum StackChangeType { Pushed, Popped, Cleared }

public class StackChangedEventArgs<T> : EventArgs
{
	public StackChangeType Type { get; }
	public T? Item { get; }
	public int NewCount { get; }

	public StackChangedEventArgs(StackChangeType type, T? item, int newCount)
	{
		Type = type;
		Item = item;
		NewCount = newCount;
	}
}

public class ObservableStack<T>
{
	public event EventHandler<StackChangedEventArgs<T>>? Changed;
	private readonly Stack<T> inner = new();

	private void OnChanged(StackChangedEventArgs<T?> args)
	{
		Changed?.Invoke(this, args);
	}

	public void Push(T item)
	{
		inner.Push(item);
		OnChanged(new StackChangedEventArgs<T?>(StackChangeType.Pushed, item, inner.Count));
	}

	public T Pop()
	{
		if (inner.Count == 0)
			throw new InvalidOperationException();
		
		var item = inner.Pop();
		OnChanged(new StackChangedEventArgs<T?>(StackChangeType.Popped, item, inner.Count));
		
		return item;
	}

	public void Clear()
	{
		if (inner.Count == 0)
			return;
		
		inner.Clear();
		OnChanged(new StackChangedEventArgs<T?>(StackChangeType.Cleared, default, 0));
	}
	
	public int Count => inner.Count;
}

public class StackOperationsLogger
{
	private readonly StringBuilder log = new();

	public void SubscribeOn<T>(ObservableStack<T> stack)
	{
		stack.Changed += (_, e) =>
		{
			if (e.Type == StackChangeType.Pushed)
				log.Append("+" + e.Item);

			else if (e.Type == StackChangeType.Popped)
				log.Append("-" + e.Item);
		};
	}

	public string GetLog() => log.ToString();
}