﻿namespace Delegates.PairsAnalysis;

public static class Analysis
{
	public static int FindMaxPeriodIndex(params DateTime[] data) => 
		data.Pairs().MaxIndex(pair => (pair.Item2 - pair.Item1).Duration());
	
	public static double FindAverageRelativeDifference(params double[] data) => 
		data.Pairs().Select(pair => (pair.Item2 - pair.Item1) / pair.Item1).Average();

	private static IEnumerable<Tuple<T, T>> Pairs<T>(this IEnumerable<T> data)
	{
		var enumerator = data.GetEnumerator();
		
		if (!enumerator.MoveNext())
			yield break;
		
		var previous = enumerator.Current;
		while (enumerator.MoveNext())
		{
			var current = enumerator.Current;
			yield return Tuple.Create(previous, current);
			previous = current;
		}
	}

	private static int MaxIndex<T, TKey>(this IEnumerable<T> data, Func<T, TKey> keySelector)
	{
		var index = 0;
		var maxIndex = 0;
		var hasValue = false;
		TKey bestKey = default;
		var comparer = Comparer<TKey>.Default;
		
		foreach (var item in data)
		{
			var key = keySelector(item);
			if (!hasValue || comparer.Compare(key, bestKey) > 0)
			{
				bestKey = key;
				maxIndex = index;
				hasValue = true;
			}
			
			index++;
		}
		
		if (!hasValue)
			throw new InvalidOperationException(nameof(data));
		
		return maxIndex;
	}

	public static int MaxIndex<T>(this IEnumerable<T> data)
	{
		return data.MaxIndex(x => x);
	}
}