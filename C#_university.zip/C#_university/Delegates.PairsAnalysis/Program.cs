using NUnitLite;

namespace Delegates.PairsAnalysis;

class Program
{
	static void Main(string[] args)
	{
		new AutoRun().Execute(args);
	}
}