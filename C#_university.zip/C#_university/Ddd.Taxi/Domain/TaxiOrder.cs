﻿using System.Globalization;
using Ddd.Taxi.Domain;
using Ddd.Taxi.Infrastructure;

// In real aplication it whould be the place where database is used to find driver by its Id.
// But in this exercise it is just a mock to simulate database

namespace Ddd.Taxi.Domain
{
	public interface IDriversRepository
	{
		Driver GetDriver(int id);
	}
	
	public class Car : ValueType<Car>
	{
		public string Model { get; }
		public string Color { get; }
		public string PlateNumber { get; }

		public Car(string model, string color, string plateNumber)
		{
			Model = model;
			Color = color;
			PlateNumber = plateNumber;
		}
	}
	
	public class DriversRepository : IDriversRepository
	{
		public Driver GetDriver(int id)
		{
			if (id == 15)
				return new Driver(
					15,
					new PersonName("Drive", "Driverson"),
					new Car("Lada sedan", "Baklazhan", "A123BT 66")
				);

			throw new ArgumentException($"Unknown driver id {id}");
		}
	}
	
	public class Driver : Entity<int>
	{
		public PersonName Name { get; }   
		public Car Car { get; }         

		public Driver(int id, PersonName name, Car car) : base(id)
		{
			Name = name;
			Car = car;
		}
	}
	
	public class TaxiOrder : Entity<int>
	{
		public PersonName ClientName { get; private set; } 
		public Address Start { get; private set; }
		public Address? Destination { get; private set; }
		public Driver? Driver { get; private set; }   
		public TaxiOrderStatus Status { get; private set; }
		public DateTime LastProgressTime { get; private set; }
		private DateTime CreationTime { get; set; }

		public TaxiOrder(int id, PersonName clientName, 
			Address start, DateTime now) : base(id)
		{
			ClientName = clientName;
			Start = start;
			Destination = null;
			Driver = null;
			Status = TaxiOrderStatus.WaitingForDriver;
			CreationTime = now;
			LastProgressTime = CreationTime;
		}
	
		public void UpdateDestination(Address destination)
		{
			if (Status is TaxiOrderStatus.Finished or TaxiOrderStatus.Canceled)
				throw new InvalidOperationException($"Cannot update destination in status {Status}");
			
			Destination = destination;
		}
		
		public void AssignDriver(Driver driver, DateTime now)
		{
			if (Status != TaxiOrderStatus.WaitingForDriver)
				throw new InvalidOperationException($"Cannot assign driver in status {Status}");
			
			Driver = driver;
			Status = TaxiOrderStatus.WaitingCarArrival;
			LastProgressTime = now;
		}
		
		public void UnassignDriver()
		{
			if (Status != TaxiOrderStatus.WaitingCarArrival)
				throw new InvalidOperationException($"Cannot unassign driver in status {Status}");
			
			Driver = null;
			Status = TaxiOrderStatus.WaitingForDriver;
			LastProgressTime = CreationTime;
		}
		
		public void StartRide(DateTime now)
		{
			if (Status != TaxiOrderStatus.WaitingCarArrival)
				throw new InvalidOperationException($"Cannot start ride in status {Status}");

			Status = TaxiOrderStatus.InProgress;
			LastProgressTime = now;
		}
		
		public void FinishRide(DateTime now)
		{
			if (Status != TaxiOrderStatus.InProgress)
				throw new InvalidOperationException($"Cannot finish ride in status {Status}");
			
			Status = TaxiOrderStatus.Finished;
			LastProgressTime = now;
		}
		
		public void Cancel(DateTime now)
		{
			if (Status is TaxiOrderStatus.InProgress 
			    or TaxiOrderStatus.Finished 
			    or TaxiOrderStatus.Canceled)
				throw new InvalidOperationException($"Cannot cancel in status {Status}");

			Status = TaxiOrderStatus.Canceled;
			LastProgressTime = now;
		}
	}
}

namespace Ddd.Taxi.Infrastructure
{
	public class TaxiApi : ITaxiApi<TaxiOrder>
	{
		private readonly IDriversRepository driversRepository;
		private readonly Func<DateTime> now;
		private int idCounter;

		public TaxiApi(IDriversRepository driversRepository, Func<DateTime> now)
		{
			this.driversRepository = driversRepository;
			this.now = now;
		}

		public TaxiOrder CreateOrderWithoutDestination(string firstName, string lastName, 
			string street, string building)
		{
			var order = new TaxiOrder(idCounter++, new PersonName(firstName, lastName), 
				new Address(street, building), now());
			
			return order;                                 
		}

		public void UpdateDestination(TaxiOrder order, string street, string building) =>
			order.UpdateDestination(new Address(street, building));

		public void AssignDriver(TaxiOrder order, int driverId)
		{
			var driver = driversRepository.GetDriver(driverId);
			order.AssignDriver(driver, now());
		}

		public string GetDriverFullInfo(TaxiOrder order)
		{
			if (order.Status == TaxiOrderStatus.WaitingForDriver)
				return null;

			var driver = order.Driver!;
			return string.Join(" ",
				"Id: " + driver.Id,
				"DriverName: " + FormatName(driver.Name.FirstName, driver.Name.LastName),
				"Color: " + driver.Car.Color,
				"CarModel: " + driver.Car.Model,
				"PlateNumber: " + driver.Car.PlateNumber
			);
		}
		
		public string GetShortOrderInfo(TaxiOrder order)
		{
			return string.Join(" ",
				"OrderId: " + order.Id,
				"Status: " + order.Status,
				"Client: " + FormatName(order.ClientName.FirstName, order.ClientName.LastName),
				"Driver: " + (order.Driver is null
					? ""
					: FormatName(order.Driver.Name.FirstName, order.Driver.Name.LastName)),
				"From: " + FormatAddress(order.Start.Street, order.Start.Building),
				"To: " + (order.Destination is null
					? ""
					: FormatAddress(order.Destination.Street, order.Destination.Building)),
				"LastProgressTime: " +
				order.LastProgressTime.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture));
		}

		private static string FormatName(string? first, string? last) =>
			string.Join(" ", new[] { first, last }.Where(s => !string.IsNullOrEmpty(s)));

		private static string FormatAddress(string? street, string? building) =>
			string.Join(" ", new[] { street, building }.Where(s => !string.IsNullOrEmpty(s)));

		public void UnassignDriver(TaxiOrder order) => order.UnassignDriver();
		public void StartRide(TaxiOrder order) => order.StartRide(now());
		public void FinishRide(TaxiOrder order) => order.FinishRide(now());
		public void Cancel(TaxiOrder order) => order.Cancel(now());
	}
}