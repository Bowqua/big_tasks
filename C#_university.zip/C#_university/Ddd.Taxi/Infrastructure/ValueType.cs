﻿using System.Reflection;

namespace Ddd.Taxi.Infrastructure;

/// <summary>
/// Базовый класс для всех Value типов.
/// </summary>
public class ValueType<T> : IEquatable<T> where T : ValueType<T>
{
    private static readonly PropertyInfo[] Property = typeof(T)
        .GetProperties(BindingFlags.Public | BindingFlags.Instance)
        .Where(p => p.GetIndexParameters().Length == 0)
        .OrderBy(p => p.Name)
        .ToArray();

    public bool Equals(T? other)
    {
        if (other is null) 
            return false;
        
        if (ReferenceEquals(this, other))
            return true;

        foreach (var property in Property)
        {
            var firstValue = property.GetValue(this);
            var secondValue = property.GetValue(other);
            
            if (!Equals(firstValue, secondValue))
                return false;
        }
        
        return true;
    }

    public override bool Equals(object? obj)
    {
        if (obj is T other)
            return Equals(other);
        
        return false;
    }

    public override int GetHashCode()
    {
        unchecked
        {
            return Property
                .Select(property => property.GetValue(this))
                .Aggregate(17, (current, value) => current * 31 + (value?.GetHashCode() ?? 0));
        }
    }

    public override string ToString()
    {
        var pairs = Property
            .Select(p => $"{p.Name}: {p.GetValue(this) ?? ""}")
            .ToArray();

        return $"{typeof(T).Name}({string.Join("; ", pairs)})";
    }
}
