using System.Diagnostics;

namespace Memory.Timers;

public class Timer : IDisposable
{
	private readonly string name;
	private readonly int level;
	private readonly StringWriter stringWriter;
	private readonly Timer? parent;
	private readonly List<Timer> children = [];
	private readonly Stopwatch stopwatch;
	private bool disposed;
	private long elapsed;

	private Timer(string name, int level, StringWriter stringWriter, Timer? parent)
	{
		this.name = name;
		this.level = level;
		this.stringWriter = stringWriter;
		this.parent = parent;
		stopwatch = Stopwatch.StartNew();
	}

	public static Timer Start(StringWriter stringWriter, string name = "*") => 
		new(name, 0, stringWriter, null);

	public Timer StartChildTimer(string name)
	{
		if (disposed)
			throw new ObjectDisposedException(nameof(Timer));
		
		var child = new Timer(name, level + 1, stringWriter, this);
		children.Add(child);
		
		return child;
	}

	public void Dispose()
	{
		if (disposed)
			return;
		
		stopwatch.Stop();
		elapsed = stopwatch.ElapsedMilliseconds;
		disposed = true;
		
		if (parent == null)
			PrintRecursive(this);
	}

	private static void PrintRecursive(Timer timer)
	{
		timer.stringWriter.Write(FormatReportLine(timer.name, timer.level, timer.elapsed));

		long childrenSum = 0;
		foreach (var child in timer.children)
		{
			PrintRecursive(child);
			childrenSum += child.elapsed;
		}

		if (timer.children.Count > 0)
		{
			var rest = timer.elapsed - childrenSum;
			timer.stringWriter.Write(FormatReportLine("Rest", timer.level + 1, rest));
		}
	}

	private static string FormatReportLine(string timerName, int level, long value)
	{
		var intro = new string(' ', level * 4) + timerName;
		return $"{intro,-20}: {value}\n";
	}
}