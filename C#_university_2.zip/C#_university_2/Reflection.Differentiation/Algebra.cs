﻿using System.Linq.Expressions;

namespace Reflection.Differentiation;

public class Algebra : ExpressionVisitor
{
    private readonly ParameterExpression z;
    private Algebra(ParameterExpression z) { this.z = z; }
    
    public static Expression<Func<double, double>> Differentiate(Expression<Func<double, double>> function)
    {
        var z = function.Parameters[0];
        var body = function.Body;
        var visitor = new Algebra(z);
        var dBody = visitor.Visit(body);
        
        return Expression.Lambda<Func<double, double>>(dBody, z);
    }

    protected override Expression VisitConstant(ConstantExpression node) => Expression.Constant(0.0);

    protected override Expression VisitParameter(ParameterExpression node) => 
        node == z ? Expression.Constant(1.0) : Expression.Constant(0.0);

    protected override Expression VisitBinary(BinaryExpression node)
    {
        switch (node.NodeType)
        {
            case ExpressionType.Add:
            {
                var du = Visit(node.Left);
                var dv = Visit(node.Right);
            
                return Expression.Add(du, dv);
            }
            case ExpressionType.Multiply:
            {
                var du = Visit(node.Left);
                var dv = Visit(node.Right);
            
                return Expression.Add(Expression.Multiply(node.Left, dv), Expression.Multiply(du, node.Right));
            }
            default:
                throw new ArgumentException($"Unsupported binary operator: {node.NodeType}");
        }
    }

    protected override Expression VisitMethodCall(MethodCallExpression node)
    {
        var method = node.Method;
        if (method.DeclaringType == typeof(Math) && method.Name is "Sin" or "Cos")
        {
            var u = node.Arguments[0];
            var du = Visit(u);
            var sin = typeof(Math).GetMethod(nameof(Math.Sin), new[] { typeof(double) });
            var cos = typeof(Math).GetMethod(nameof(Math.Cos), new[] { typeof(double) });

            if (method.Name == "Sin")
                return Expression.Multiply(Expression.Call(cos, u), du);

            return Expression.Negate(Expression.Multiply(Expression.Call(sin, u), du));
        }

        throw new ArgumentException($"Unsupported method: {method.Name}");
    }

    protected override Expression VisitMember(MemberExpression node)
    {
        Visit(node.Expression);
        throw new ArgumentException($"Unsupported member access: {node.Member.Name}");
    }
}
    
