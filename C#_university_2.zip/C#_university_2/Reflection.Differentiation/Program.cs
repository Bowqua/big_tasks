using NUnitLite;

namespace Reflection.Differentiation;

class Program
{
	static void Main(string[] args)
	{
		new AutoRun().Execute(args);
	}
}