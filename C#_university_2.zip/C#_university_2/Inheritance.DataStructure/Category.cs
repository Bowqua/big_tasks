﻿namespace Inheritance.DataStructure;

public class Category : IComparable<Category>, IComparable
{
    private MessageType MessageType { get; }
    private MessageTopic MessageTopic { get; }
    private string Product { get; }

    public Category(string product, MessageType messageType, MessageTopic messageTopic)
    {
        Product = product;
        MessageType = messageType;
        MessageTopic = messageTopic;
    }

    public override bool Equals(object? obj)
    {
        if (obj is not Category category)
            return false;

        return category.Product == Product
               && category.MessageTopic == MessageTopic
               && category.MessageType == MessageType;
    }

    public override int GetHashCode() => (Product, MessageType, MessageTopic).GetHashCode();

    public int CompareTo(Category? category)
    {
        if (category == null)
            return 1;

        var productComparison = string.Compare(Product, category.Product, StringComparison.Ordinal);
        if (productComparison != 0)
            return productComparison;
        
        var messageTypeComparison = MessageType.CompareTo(category.MessageType);
        if (messageTypeComparison != 0)
            return messageTypeComparison;
        
        return MessageTopic.CompareTo(category.MessageTopic);
    }
    
    public int CompareTo(object? obj)
    {
        if (obj is Category category)
            return CompareTo(category);
        
        throw new ArgumentException("Object is not a Category");
    }

    public static bool operator <=(Category category1, Category category2) =>
        category1.CompareTo(category2) <= 0;

    public static bool operator >=(Category category1, Category category2) =>
        category1.CompareTo(category2) >= 0;

    public static bool operator <(Category category1, Category category2) =>
        category1.CompareTo(category2) < 0;

    public static bool operator >(Category category1, Category category2) =>
        category1.CompareTo(category2) > 0;

    public static bool operator ==(Category category1, Category category2) =>
        Equals(category1, category2);

    public static bool operator !=(Category category1, Category category2) =>
        !Equals(category1, category2);
    
    public override string ToString() => $"{Product}.{MessageType}.{MessageTopic}";
}