using NUnitLite;

namespace Inheritance.DataStructure;

internal class Program
{
	private static void Main(string[] args)
	{
		new AutoRun().Execute(args);
	}
}