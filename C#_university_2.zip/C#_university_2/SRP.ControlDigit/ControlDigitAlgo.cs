namespace SRP.ControlDigit;

public static class Extensions
{
    public static IEnumerable<int> DigitsFromRight(this long number)
    {
        do
        {
            yield return (int)(number % 10);
            number /= 10;
        }
        
        while (number > 0);
    }

    public static int ComplementToNextMultiple10(this int value)
    {
        var mod = value % 10;
        return mod == 0 ? 0 : 10 - mod;
    }
}

public static class ControlDigitAlgo
{
    public static int Upc(long number)
    {
        var sum = number
            .DigitsFromRight()
            .Select((digit, index) => digit * (index % 2 == 0 ? 3 : 1))
            .Sum();
        
        return sum.ComplementToNextMultiple10();
    }

    public static char Isbn10(long number)
    {
        var digits = GetIsbnDigits(number);
        var sum = digits
            .Select((digit, index) => digit * (10 - index))
            .Sum();
        
        var remainder = sum % 11;
        var check = (11 - remainder) % 11;
        
        return check == 10 ? 'X' : (char)('0' + check);
    }

    public static int Luhn(long number)
    {
        var sum = number
            .DigitsFromRight()
            .Select((digit, index) => index % 2 == 0 ? AdjustLuhn(digit) : digit)
            .Sum();
        
        return sum.ComplementToNextMultiple10();
    }

    private static IEnumerable<int> GetIsbnDigits(long number)
    {
        var raw = number.ToString();
        var padded = raw.PadLeft(9, '0');
        
        foreach (var ch in padded)
            yield return ch - '0';
    }

    private static int AdjustLuhn(int digit) => digit * 2 > 9 ? digit * 2 - 9 : digit * 2;
}