﻿// ReSharper disable All
#pragma warning disable 649

using System;

namespace Incapsulation.EnterpriseTask
{
    public class Transaction
    {
        public double Amount;
        public Guid EnterpriseGuid;
    }
}