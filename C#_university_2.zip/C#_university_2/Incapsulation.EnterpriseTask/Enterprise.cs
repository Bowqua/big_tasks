﻿namespace Incapsulation.EnterpriseTask;

public class Enterprise
{
    public readonly Guid Guid;
    public string Name { get; set; }
	
    private string inn;
    public string Inn
    {
        get => inn; 
        set
        {
            if (value.Length != 10 || !value.All(char.IsDigit))
                throw new ArgumentException("Inn must consist of exactly 10 digits", nameof(value));
			
            inn = value;
        }
    }
	
    public Enterprise(Guid guid) => Guid = guid;
	
    public DateTime EstablishDate { get; set; }
	
    public TimeSpan ActiveTimeSpan => DateTime.Now - EstablishDate;

    public double GetTotalTransactionsAmount()
    {
        DataBase.OpenConnection();
        return DataBase.Transactions().Where(z => z.EnterpriseGuid == Guid).Sum(transaction => transaction.Amount);
    }
}