﻿namespace Incapsulation.EnterpriseTask;

class DataBase
{
	public static void OpenConnection()
	{
		throw new NotImplementedException();
	}

	public  static IEnumerable<Transaction> Transactions()
	{
		throw new NotImplementedException();
	}
}