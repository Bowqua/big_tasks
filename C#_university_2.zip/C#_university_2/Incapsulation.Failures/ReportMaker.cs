﻿namespace Incapsulation.Failures;

public class ReportMaker
{
	public enum FailureType
	{
		UnexpectedShutdown = 0,
		NonResponding = 1,
		HardwareFailures = 2,
		ConnectionFailures = 3
	}
	
	private class Device
	{
		public int Id { get; }
		public string Name { get; }

		public Device(int id, string name)
		{
			Id = id;
			Name = name;
		}
	}

	private class Failure
	{
		private FailureType Type { get; }
		public DateTime Date { get; }
		public int DeviceId { get; }

		public Failure(FailureType type, DateTime date, int deviceId)
		{
			Type = type;
			Date = date;
			DeviceId = deviceId;
		}

		public bool IsSerious() => Type is FailureType.HardwareFailures or FailureType.UnexpectedShutdown;
	}
	
	private static List<string> FindDevicesFailedBeforeDate(IEnumerable<Device> devices, IEnumerable<Failure> failures,
		DateTime dateBeforeFails)
	{
		var device = failures
			.Where(failure => failure.Date < dateBeforeFails && failure.IsSerious())
			.Join(devices, failure => failure.DeviceId, device => device.Id, (_, device) => device.Name)
			.Distinct()
			.ToList();
		
		return device;
	}
	
	public static List<string> FindDevicesFailedBeforeDateObsolete(
		int day,
		int month,
		int year,
		int[] failureTypes, 
		int[] deviceId, 
		object[][] times,
		List<Dictionary<string, object>> devices)
	{
		var cutoff = new DateTime(year, month, day);
		var deviceForNewMethod = new List<Device>();
		var failureForNewMethod = new List<Failure>();
		
		foreach (var device in devices)
		{
			var id = Convert.ToInt32(device["DeviceId"]);
			var name = Convert.ToString(device["Name"]);
			
			deviceForNewMethod.Add(new Device(id, name));
		}
		
		for (var i = 0; i < failureTypes.Length; i++)
		{
			 var time = times[i];
			 var date = new DateTime(Convert.ToInt32(time[2]), Convert.ToInt32(time[1]), Convert.ToInt32(time[0]));
			 var failure = new Failure((FailureType)failureTypes[i], date, deviceId[i]);
			 
			 failureForNewMethod.Add(failure);
		}

		return FindDevicesFailedBeforeDate(deviceForNewMethod, failureForNewMethod, cutoff);
	}
}