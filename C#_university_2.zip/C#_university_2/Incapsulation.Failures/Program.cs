using NUnitLite;

namespace Incapsulation.Failures;

class Program
{
	static void Main(string[] args)
	{
		new AutoRun().Execute(args);
	}
}