namespace Inheritance.Geometry.Visitor;

public interface IVisitor<T>
{
	T Visit(Ball ball);
	T Visit(RectangularCuboid cuboid);
	T Visit(Cylinder cylinder);
	T Visit(CompoundBody compoundBody);
}

public abstract class Body
{
	public Vector3 Position { get; }

	protected Body(Vector3 position)
	{
		Position = position;
	}
	
	public abstract T Accept<T>(IVisitor<T> visitor);
}

public class Ball : Body
{
	public double Radius { get; }

	public Ball(Vector3 position, double radius) : base(position)
	{
		Radius = radius;
	}

	public override T Accept<T>(IVisitor<T> visitor) => 
		visitor.Visit(this);
}

public class RectangularCuboid : Body
{
	public double SizeX { get; }
	public double SizeY { get; }
	public double SizeZ { get; }

	public RectangularCuboid(Vector3 position, double sizeX, double sizeY, double sizeZ) : base(position)
	{
		SizeX = sizeX;
		SizeY = sizeY;
		SizeZ = sizeZ;
	}

	public override T Accept<T>(IVisitor<T> visitor) => 
		visitor.Visit(this);
}

public class Cylinder : Body
{
	public double SizeZ { get; }

	public double Radius { get; }

	public Cylinder(Vector3 position, double sizeZ, double radius) : base(position)
	{
		SizeZ = sizeZ;
		Radius = radius;
	}

	public override T Accept<T>(IVisitor<T> visitor) => 
		visitor.Visit(this);
}

public class CompoundBody : Body
{
	public IReadOnlyList<Body> Parts { get; }

	public CompoundBody(IReadOnlyList<Body> parts) : base(parts[0].Position)
	{
		Parts = parts;
	}

	public override T Accept<T>(IVisitor<T> visitor) => 
		visitor.Visit(this);
}

public class BoundingBoxVisitor : IVisitor<RectangularCuboid>
{
	public RectangularCuboid Visit(Ball ball)
	{
		var minX = ball.Position.X - ball.Radius;
		var minY = ball.Position.Y - ball.Radius;
		var minZ = ball.Position.Z - ball.Radius;
		
		var maxX = ball.Position.X + ball.Radius;
		var maxY = ball.Position.Y + ball.Radius;
		var maxZ = ball.Position.Z + ball.Radius;
		
		var centerX = (minX + maxX) / 2;
		var centerY = (minY + maxY) / 2;
		var centerZ = (minZ + maxZ) / 2;
		
		var sizeX = maxX - minX;
		var sizeY = maxY - minY;
		var sizeZ = maxZ - minZ;
		
		return new RectangularCuboid(new Vector3(centerX, centerY, centerZ), sizeX, sizeY, sizeZ); 
	}

	public RectangularCuboid Visit(RectangularCuboid cuboid) => cuboid;

	public RectangularCuboid Visit(Cylinder cylinder)
	{
		var minX = cylinder.Position.X - cylinder.Radius;
		var minY = cylinder.Position.Y - cylinder.Radius;
		var minZ = cylinder.Position.Z - cylinder.SizeZ / 2;
		
		var maxX = cylinder.Position.X + cylinder.Radius;
		var maxY = cylinder.Position.Y + cylinder.Radius;
		var maxZ = cylinder.Position.Z + cylinder.SizeZ / 2;
		
		var centerX = (minX + maxX) / 2;
		var centerY = (minY + maxY) / 2;
		var centerZ = (minZ + maxZ) / 2;
		
		var sizeX = maxX - minX;
		var sizeY = maxY - minY;
		var sizeZ = maxZ - minZ;
		
		return new RectangularCuboid(new Vector3(centerX, centerY, centerZ), sizeX, sizeY, sizeZ);
	}

	public RectangularCuboid Visit(CompoundBody compoundBody)
	{
		var firstBox = compoundBody.Parts[0].Accept(this);;
		
		var minX = firstBox.Position.X - firstBox.SizeX / 2;
		var maxX = firstBox.Position.X + firstBox.SizeX / 2;
		
		var minY = firstBox.Position.Y - firstBox.SizeY / 2;
		var maxY = firstBox.Position.Y + firstBox.SizeY / 2;
		
		var minZ = firstBox.Position.Z - firstBox.SizeZ / 2;
		var maxZ = firstBox.Position.Z + firstBox.SizeZ / 2;

		foreach (var part in compoundBody.Parts.Skip(1))
		{
			var box = part.Accept(this);
			
			var boxMinX = box.Position.X - box.SizeX / 2;
			var boxMinY = box.Position.Y - box.SizeY / 2;
			var boxMinZ = box.Position.Z - box.SizeZ / 2;
			
			var boxMaxX = box.Position.X + box.SizeX / 2;
			var boxMaxY = box.Position.Y + box.SizeY / 2;
			var boxMaxZ = box.Position.Z + box.SizeZ / 2;
			
			minX = Math.Min(minX, boxMinX);
			maxX = Math.Max(maxX, boxMaxX);
			
			minY = Math.Min(minY, boxMinY);
			maxY = Math.Max(maxY, boxMaxY);
			
			minZ = Math.Min(minZ, boxMinZ);
			maxZ = Math.Max(maxZ, boxMaxZ);
		}
		
		var centerX = (minX + maxX) / 2;
		var centerY = (minY + maxY) / 2;
		var centerZ = (minZ + maxZ) / 2;
		
		var sizeX = maxX - minX;
		var sizeY = maxY - minY;
		var sizeZ = maxZ - minZ;
		
		return new RectangularCuboid(new Vector3(centerX, centerY, centerZ), sizeX, sizeY, sizeZ);
	}
}

public class BoxifyVisitor : IVisitor<Body>
{
	public Body Visit(Ball ball) => ball.Accept(new BoundingBoxVisitor());

	public Body Visit(RectangularCuboid cuboid) => cuboid;

	public Body Visit(Cylinder cylinder) => cylinder.Accept(new BoundingBoxVisitor());

	public Body Visit(CompoundBody compoundBody)
	{
		var newParts = compoundBody.Parts
			.Select(part => part.Accept(this))
			.ToList();
		return new CompoundBody(newParts);
	}
}


