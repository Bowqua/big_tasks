namespace Inheritance.Geometry;

public static class Constants
{
	public static double Inaccuracy => 0.0001;
}