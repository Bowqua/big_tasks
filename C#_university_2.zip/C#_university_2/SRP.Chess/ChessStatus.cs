namespace Chess;

public enum ChessStatus
{
	Ok = 0,
	Check,
	Stalemate,
	Mate
}