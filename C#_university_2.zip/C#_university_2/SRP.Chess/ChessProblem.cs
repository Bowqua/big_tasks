namespace Chess;

public class ChessProblem
{
	private readonly Board board;

	public ChessProblem(Board board)
	{
		this.board = board;
	}

	// Определяет мат, шах или пат белым.
	public ChessStatus CalculateChessStatus()
	{
		// var isCheck = IsCheckForWhite();
		// var hasMoves = false;
		// foreach (var locFrom in board.GetPieces(PieceColor.White))
		// {
		// 	foreach (var locTo in board.GetPiece(locFrom)!.GetMoves(locFrom, board))
		// 	{
		// 		var old = board.GetPiece(locTo);
		// 		board.Set(locTo, board.GetPiece(locFrom));
		// 		board.Set(locFrom, null);
		// 		if (!IsCheckForWhite())
		// 			hasMoves = true;
		// 		board.Set(locFrom, board.GetPiece(locTo));
		// 		board.Set(locTo, old);
		// 	}
		// }
		//
		// if (isCheck)
		// 	return hasMoves ? ChessStatus.Check : ChessStatus.Mate;
		//
		// return hasMoves ? ChessStatus.Ok : ChessStatus.Stalemate;

		var inCheck = IsWhiteInCheck();
		var hasMoves = HasWhiteAnyLegalMoves();

		if (inCheck)
			return hasMoves ? ChessStatus.Check : ChessStatus.Mate;
		
		return hasMoves ? ChessStatus.Ok : ChessStatus.Stalemate;
	}

	// Шах ли для белых? (check — это шах)
	// private bool IsCheckForWhite()
	// {
	// 	var isCheck = false;
	// 	foreach (var loc in board.GetPieces(PieceColor.Black))
	// 	{
	// 		var piece = board.GetPiece(loc)!;
	// 		var moves = piece.GetMoves(loc, board);
	// 		foreach (var destination in moves)
	// 		{
	// 			if (board.GetPiece(destination).Is(PieceColor.White, PieceType.King))
	// 				isCheck = true;
	// 		}
	// 	}
	// 	
	// 	if (isCheck) 
	// 		return true;
	// 	
	// 	return false;
	// }
	
	// -------------
	
	private bool IsWhiteInCheck()
	{
		foreach (var from in board.GetPieces(PieceColor.Black))
		{
			var attacker = board.GetPiece(from)!;
			if (attacker.GetMoves(from, board).Any(to => 
				    board.GetPiece(to).Is(PieceColor.White, PieceType.King)))
				return true;
		}
		
		return false;
	}

	private bool HasWhiteAnyLegalMoves()
	{
		foreach (var from in board.GetPieces(PieceColor.White))
		{
			var piece = board.GetPiece(from)!;
			if (piece == null)
				continue;
			
			if (piece.GetMoves(from, board).Any(to => 
				    IsMoveSafeForWhite(from, to)))
				return true;
		}
		
		return false;
	}

	private bool IsMoveSafeForWhite(Location from, Location to)
	{
		var movingPiece = board.GetPiece(from)!;
		var capturedPiece = board.GetPiece(to)!;
		
		board.Set(to, movingPiece);
		board.Set(from, null);
		
		var isInCheck = IsWhiteInCheck();
		board.Set(from, movingPiece);
		board.Set(to, capturedPiece);
		
		return !isInCheck;
	}
	
	
}

public static class ChessExtensions
{
}