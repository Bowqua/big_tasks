﻿namespace Chess;

public record Location(int X, int Y);