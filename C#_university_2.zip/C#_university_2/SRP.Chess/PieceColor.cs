namespace Chess;

public enum PieceColor
{
	Black,
	White
}