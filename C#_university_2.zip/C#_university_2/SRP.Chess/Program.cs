﻿using NUnitLite;

namespace Chess;

public class Program
{
	public static void Main(string[] args)
	{
		new AutoRun().Execute(args);
	}
}