namespace Inheritance.MapObjects;

interface IHasArmy
{
	public Army Army { get; }
}

interface IHasTreasure
{
	public Treasure Treasure { get; }
}

interface IHasOwner
{
	public int Owner { set; }
}

public class Dwelling : IHasOwner
{
	public int Owner { get; set; }
}

public class Mine : IHasOwner, IHasArmy, IHasTreasure
{
	public int Owner { get; set; }
	public Army Army { get; set; }
	public Treasure Treasure { get; set; }
}

public class Creeps : IHasArmy, IHasTreasure
{
	public Army Army { get; set; }
	public Treasure Treasure { get; set; }
}

public class Wolves : IHasArmy
{
	public Army Army { get; set; }
}

public class ResourcePile : IHasTreasure
{
	public Treasure Treasure { get; set; }
}

public static class Interaction
{
	public static void Make(Player player, object mapObject) 
	{
		if (mapObject is IHasArmy army && !player.CanBeat(army.Army))
		{
			player.Die(); 
			return;
		}
		
		if (mapObject is IHasTreasure treasure)
			player.Consume(treasure.Treasure);
		
		if (mapObject is IHasOwner owner)
			owner.Owner = player.Id;
	}	
}

public static class ListInterfaces
{
	public static List<T> Interfaces<T>()
	{
		
	} 
}


// public class Action
// {
// 	public void GetTreasure()
// 	{
// 	}
//
// 	public void GetOwner()
// 	{
// 	}
//
// 	public void GetArmy() { }
// }
//
// public abstract class Character
// {
// 	public abstract object Creeps { get; set; }
// 	public abstract object Wolves { get; set; }
// 	public abstract object ResourcePiles { get; set; }
// 	public abstract object Dwelling { get; set; }
// 	public abstract object Mine { get; set; }
// }
//
// public class Wolves : Action
// {
// 	private Wolves wolves;
//
// 	public Wolves(Wolves wolves)
// 	{
// 		this.wolves = wolves;
// 	}
//
// 	private void GetWolves()
// 	{
// 		wolves.GetArmy();
// 	}
// }
//
// public class Dwelling : Action
// {
// 	private Dwelling dwelling;
// 	
// 	public Dwelling(Dwelling dwelling)
// 	{
// 		this.dwelling = dwelling;
// 	}
//
// 	private void GetWolves()
// 	{
// 		dwelling.GetOwner();
// 	}
// }