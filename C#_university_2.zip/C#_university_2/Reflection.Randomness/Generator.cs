﻿using System.Globalization;
using System.Reflection;

namespace Reflection.Randomness;

public class Generator<T> 
{
    private readonly List<(PropertyInfo propertyInfo, IContinuousDistribution distribution)> plan;
    public Generator()
    {
        var type = typeof(T);
        var properties = type.GetProperties();
        plan = new List<(PropertyInfo, IContinuousDistribution)>();

        foreach (var property in properties)
        {
            if (property.PropertyType != typeof(double))
                continue;

            if (!property.CanWrite)
                continue;

            var attribute = property.GetCustomAttribute<FromDistributionAttribute>();
            if (attribute == null)
                continue;

            var distributionType = attribute.Type;
            if (distributionType == null || !typeof(IContinuousDistribution).IsAssignableFrom(distributionType))
                throw new ArgumentException($"Wrong distribution type: {distributionType?.Name}");

            var parameters = attribute.Parameters;
            var constructor = distributionType.GetConstructors().FirstOrDefault(x =>
            {
                var parameterChecking = x.GetParameters();
                return parameterChecking.Length == parameters.Length &&
                       parameterChecking.All(pi =>
                       {
                           var code = Type.GetTypeCode(pi.ParameterType);
                           return code is TypeCode.Double
                               or TypeCode.Int32
                               or TypeCode.Int64;
                       });
            });

            if (constructor == null)
                throw new ArgumentException($"No constructor(double x{parameters.Length}) in {distributionType.Name}");

            var parameterInfo = constructor.GetParameters();
            var convertedArguments = new object[parameterInfo.Length];
            
            for (var i = 0; i < parameters.Length; i++)
                convertedArguments[i] = Convert.ChangeType(parameters[i], 
                    parameterInfo[i].ParameterType, CultureInfo.InvariantCulture);
            
            var distribution = (IContinuousDistribution)constructor.Invoke(convertedArguments);
            plan.Add((property, distribution));
        }
    }

    public T Generate(Random random)
    {
        var result = Activator.CreateInstance<T>();
        foreach (var (propertyInfo, parameterDistribution) in plan)
            propertyInfo.SetValue(result, parameterDistribution.Generate(random));
        
        return result;
    }
}

[AttributeUsage(AttributeTargets.Property)]
public class FromDistributionAttribute : Attribute
{
    public Type Type { get; }
    public double[] Parameters { get; }
    
    public FromDistributionAttribute(Type type, params double[] parameters)
    {
        Type = type;
        Parameters = parameters;
    }
}