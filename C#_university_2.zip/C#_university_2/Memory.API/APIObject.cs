﻿namespace Memory.API;

public class APIObject : IDisposable
{
    private readonly int id;
    private bool disposed;

    public APIObject(int id)
    {
        this.id = id;
        MagicAPI.Allocate(id);
    }

    ~APIObject()
    {
        Dispose(false);
    }
    
    public void Dispose()
    {
        Dispose(true);
        GC.SuppressFinalize(this);
    }

    private void Dispose(bool disposing)
    {
        if (disposed)
            return;
        
        MagicAPI.Free(id);
        disposed = true;
    }
}