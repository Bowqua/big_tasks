﻿using System.Numerics;

namespace Incapsulation.RationalNumbers;

public class Rational
{
    public int Numerator { get; }
    public int Denominator { get; }
    public bool IsNan => Denominator == 0;
    
    public Rational(int numerator, int denominator = 1)
    {
        if (denominator == 0)
        {
            Numerator = 0;
            Denominator = 0;
            return;
        }
        
        if (denominator < 0)
        {
            denominator *= -1;
            numerator *= -1;
        }

        var gcd = BigInteger.GreatestCommonDivisor(Math.Abs(numerator), Math.Abs(denominator));
        numerator /= (int)gcd;
        denominator /= (int)gcd;

        if (numerator == 0)
            denominator = 1;

        Numerator = numerator;
        Denominator = denominator;
    }
    
    public static Rational operator *(Rational a, Rational b) =>
        a.IsNan || b.IsNan ? NaN
            : new Rational(a.Numerator * b.Numerator, a.Denominator * b.Denominator);

    public static Rational operator +(Rational a, Rational b) =>
        a.IsNan || b.IsNan ? NaN
            : new Rational(a.Numerator * b.Denominator + b.Numerator * a.Denominator,
                a.Denominator * b.Denominator);
    
    public static Rational operator -(Rational a, Rational b) =>
        a.IsNan || b.IsNan ? NaN
            : new Rational(a.Numerator * b.Denominator - b.Numerator * a.Denominator,
                a.Denominator * b.Denominator);

    public static Rational operator /(Rational a, Rational b)
    {
        if (a.IsNan || b.IsNan) 
            return NaN;
        
        if (b.Numerator == 0) 
            return NaN;
        
        return new Rational(a.Numerator * b.Denominator, a.Denominator * b.Numerator);
    }

    private static readonly Rational NaN = new(1, 0);
    public static implicit operator Rational(int value) => new(value);
    public static implicit operator double(Rational r) => r.IsNan ? double.NaN 
        : (double)r.Numerator / r.Denominator;    
    
    public static explicit operator int(Rational rational)
    {
        if (rational.IsNan) 
            throw new InvalidCastException();
        
        if (rational.Numerator % rational.Denominator != 0) 
            throw new Exception();
        
        return rational.Numerator / rational.Denominator;
    }
}