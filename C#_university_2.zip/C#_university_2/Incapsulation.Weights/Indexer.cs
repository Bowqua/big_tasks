﻿namespace Incapsulation.Weights;

public class Indexer
{
    private double[] array;
    private readonly int start;
    public readonly int Length;

    public double this[int index]
    {
        get => IsOutOfBounds(index, Length) 
            ? throw new IndexOutOfRangeException("Index is out of range") 
            : array[start + index];
        
        set
        {
            if (IsOutOfBounds(index, Length))
                throw new IndexOutOfRangeException("Index is out of range");
            
            array[start + index] = value;
        }
    }

    public Indexer(double[] array, int start, int length)
    {
        if (array == null)
            throw new ArgumentException("Array must not be negative", nameof(array));
        
        if (start < 0 || length < 0 || start + length > array.Length)
            throw new ArgumentException("Start and length are out of bounds", nameof(start));
        
        this.array = array;
        this.start = start;
        Length = length;
    }

    private static bool IsOutOfBounds(int index, int length) => index < 0 || index >= length;
}