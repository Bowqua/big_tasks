﻿namespace Generics.Tables;

public class Table<TRow, TColumn, TValue>
{
    public OpenIndexer Open => new(this);
    public ExistedIndexer Existed => new(this);
    public IEnumerable<TRow> Rows => rows;
    public IEnumerable<TColumn> Columns => columns;
    
    public void AddRow(TRow row) => rows.Add(row);
    public void AddColumn(TColumn column) => columns.Add(column);
    
    private readonly Dictionary<(TRow Row, TColumn Column), TValue> dictionary = new();
    private readonly HashSet<TRow> rows = new();
    private readonly HashSet<TColumn> columns = new();

    public class OpenIndexer
    {
        public OpenIndexer(Table<TRow, TColumn, TValue> table) => this.table = table;
        private readonly Table<TRow, TColumn, TValue> table;

        public TValue this[TRow row, TColumn column]
        {
            get => table.dictionary.TryGetValue((row, column), out var value) ? value : default!;

            set
            {
                table.rows.Add(row);
                table.columns.Add(column);

                if (EqualityComparer<TValue>.Default.Equals(value, default))
                    table.dictionary.Remove((row, column));

                else
                    table.dictionary[(row, column)] = value;
            }
        }
    }
    
    public class ExistedIndexer
    {
        public ExistedIndexer(Table<TRow, TColumn, TValue> table) => this.table = table;
        private readonly Table<TRow, TColumn, TValue> table;
        
        public TValue this[TRow row, TColumn column]
        {
            get
            {
                EnsureDeclared(row, column);
                return table.dictionary.TryGetValue((row, column), out var value) ? value : default!;
            }

            set
            {
                EnsureDeclared(row, column);
                
                if (EqualityComparer<TValue>.Default.Equals(value, default))
                    table.dictionary.Remove((row, column));
                
                else 
                    table.dictionary[(row, column)] = value;
            }
        }
        
        private void EnsureDeclared(TRow row, TColumn column)
        {
            if (!table.rows.Contains(row) || !table.columns.Contains(column))
                throw new ArgumentException($"row {row} or column {column} does not exist in the table");
        }
    }
}