using NUnitLite;

namespace Generics.Tables;

class Program
{
	static void Main(string[] args)
	{
		new AutoRun().Execute(args);
	}
}