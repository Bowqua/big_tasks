using System;
using System.Linq;
using Avalonia.Controls;
using FractalPainting.App.Fractals;
using FractalPainting.Infrastructure.Common;
using FractalPainting.Infrastructure.UiActions;
using Ninject;
using Ninject.Extensions.Factory;

namespace FractalPainting.App
{
	public static class DIContainerTask
	{
		public static MainWindow CreateMainWindow()
		{
			var kernel = ConfigureContainer();
			return kernel.Get<MainWindow>();
		}

		public static StandardKernel ConfigureContainer()
		{
			var kernel = new StandardKernel();

			kernel.Bind<SettingsManager>()
				.ToMethod(_ => new SettingsManager(new XmlObjectSerializer(), new FileBlobStorage()))
				.InSingletonScope();

			kernel.Bind<AppSettings>()
				.ToMethod(ctx => ctx.Kernel.Get<SettingsManager>().Load())
				.InSingletonScope();

			kernel.Bind<ImageSettings>()
				.ToMethod(ctx => ctx.Kernel.Get<AppSettings>().ImageSettings)
				.InSingletonScope();

			kernel.Bind<IImageController>().To<AvaloniaImageController>().InSingletonScope();
			kernel.Bind<Palette>().ToSelf().InSingletonScope();

			kernel.Bind<MainWindow>().ToSelf().InSingletonScope();
			kernel.Bind<Func<Window>>()
				.ToMethod(ctx => () => ctx.Kernel.Get<MainWindow>())
				.InSingletonScope();

			kernel.Bind<KochPainter>().ToSelf().InSingletonScope();
			kernel.Bind<DragonPainter>().ToSelf();               
			kernel.Bind<IDragonPainterFactory>().ToFactory();    

			kernel.Bind<IUiAction>().To<SaveImageAction>().InSingletonScope();
			kernel.Bind<IUiAction>().To<ImageSettingsAction>().InSingletonScope();
			kernel.Bind<IUiAction>().To<PaletteSettingsAction>().InSingletonScope();
			kernel.Bind<IUiAction>().To<KochFractalAction>().InSingletonScope();
			kernel.Bind<IUiAction>().To<DragonFractalAction>().InSingletonScope();
			kernel.Bind<IUiAction[]>().ToMethod(ctx => ctx.Kernel.GetAll<IUiAction>().ToArray());

			return kernel;
		}
	}

	public interface IDragonPainterFactory
	{
		DragonPainter Create(DragonSettings settings);
	}

	public class DragonFractalAction : IUiAction
	{
		public MenuCategory Category => MenuCategory.Fractals;
		public string Name => "Дракон";
		public event EventHandler? CanExecuteChanged;
		private readonly Func<Window> getMainWindow;
		private readonly IDragonPainterFactory factory;

		public DragonFractalAction(Func<Window> getMainWindow, IDragonPainterFactory factory)
		{
			this.getMainWindow = getMainWindow;
			this.factory = factory;
		}

		public async void Execute(object? parameter)
		{
			var settings = new DragonSettingsGenerator(new Random()).Generate();
			await new UI.SettingsForm(settings).ShowDialog(getMainWindow());
			factory.Create(settings).Paint();
		}
		
		public bool CanExecute(object? parameter) => true;
	}

	public class KochFractalAction : IUiAction
	{
		public MenuCategory Category => MenuCategory.Fractals;
		public string Name => "Кривая Коха";
		public event EventHandler? CanExecuteChanged;
		private readonly Lazy<KochPainter> painter;

		public KochFractalAction(Lazy<KochPainter> painter)
		{
			this.painter = painter;
		}
		
		public void Execute(object? parameter) => painter.Value.Paint();
		public bool CanExecute(object? parameter) => true;
	}
}

namespace FractalPainting.App.Fractals
{
	using System;
	using System.Linq;
	using Avalonia;
	using Avalonia.Media;
	using Infrastructure.Common;

	public class DragonPainter
	{
		private readonly IImageController imageController;
		private readonly DragonSettings settings;
		private readonly Palette palette;

		public DragonPainter(IImageController imageController, DragonSettings settings, Palette palette)
		{
			this.imageController = imageController;
			this.settings = settings;
			this.palette = palette;
		}

		public void Paint()
		{
			var context = imageController.CreateDrawingContext();
			var imageSize = imageController.GetImageSize();
			var size = Math.Min(imageSize.Width, imageSize.Height) / 2.1f;

			var backgroundBrush = new SolidColorBrush(palette.BackgroundColor);
			var primaryBrush = new SolidColorBrush(palette.PrimaryColor);
			context.FillRectangle(backgroundBrush, new Rect(0, 0, imageSize.Width, imageSize.Height));

			var random = new Random();
			var cosa = (float)Math.Cos(settings.Angle1);
			var sina = (float)Math.Sin(settings.Angle1);
			var cosb = (float)Math.Cos(settings.Angle2);
			var sinb = (float)Math.Sin(settings.Angle2);
			var shiftX = settings.ShiftX * size * 0.8f;
			var shiftY = settings.ShiftY * size * 0.8f;
			var scale = settings.Scale;
			var p = new Point(0, 0);

			foreach (var _ in Enumerable.Range(0, settings.IterationsCount))
			{
				context.FillRectangle(primaryBrush,
					new Rect(imageSize.Width / 3f + p.X, imageSize.Height / 2f + p.Y, 1, 1));

				if (random.Next(0, 2) == 0)
					p = new Point(scale * (p.X * cosa - p.Y * sina), scale * (p.X * sina + p.Y * cosa));
				
				else
					p = new Point(scale * (p.X * cosb - p.Y * sinb) + (float)shiftX,
								  scale * (p.X * sinb + p.Y * cosb) + (float)shiftY);
			}

			imageController.UpdateUi();
		}
	}
}
