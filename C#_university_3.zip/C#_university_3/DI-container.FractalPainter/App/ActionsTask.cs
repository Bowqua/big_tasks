using System;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Markup.Xaml;
using Avalonia.Platform.Storage;
using FluentAssertions.Common;
using FractalPainting.Infrastructure.Common;
using FractalPainting.Infrastructure.UiActions;
using FractalPainting.UI;

namespace FractalPainting.App;

public class ImageSettingsAction : IUiAction
{
    public MenuCategory Category => MenuCategory.Settings;
    public event EventHandler? CanExecuteChanged;
    public string Name => "Изображение...";

    private readonly ImageSettings imageSettings;
    private readonly IImageController imageController;
    private readonly Func<Window> getMainWindow;

    public ImageSettingsAction(IImageController imageController, 
        ImageSettings imageSettings, Func<Window> getMainWindow)
    {
        this.imageSettings = imageSettings;
        this.imageController = imageController;
        this.getMainWindow = getMainWindow;
    }

    public async void Execute(object? parameter)
    {
        await new SettingsForm(imageSettings).ShowDialog(getMainWindow());
        imageController.RecreateImage(imageSettings);
    }
    
    public bool CanExecute(object? parameter) => true;
}

public class SaveImageAction : IUiAction
{
    public MenuCategory Category => MenuCategory.File;
    public event EventHandler? CanExecuteChanged;
    public string Name => "Сохранить...";

    private readonly IImageController imageController;
    private readonly Func<Window> getMainWindow;

    public SaveImageAction(IImageController imageController, Func<Window> getMainWindow)
    {
        this.imageController = imageController;
        this.getMainWindow = getMainWindow;
    }

    public async void Execute(object? settings)
    {
        var topLevel = TopLevel.GetTopLevel(getMainWindow());
        if (topLevel is null) 
            return;

        var options = new FilePickerSaveOptions
        {
            Title = "Сохранить изображение",
            SuggestedFileName = "image.bmp",
        };
        
        var saveFile = await topLevel.StorageProvider.SaveFilePickerAsync(options);
        if (saveFile is not null)
            imageController.SaveImage(saveFile.Path.AbsolutePath);
    }
    
    public bool CanExecute(object? parameter) => true;
}

public class PaletteSettingsAction : IUiAction
{
    public MenuCategory Category => MenuCategory.Settings;
    public event EventHandler? CanExecuteChanged;
    public string Name => "Палитра...";

    private readonly Palette palette;
    private readonly Func<Window> getMainWindow;

    public PaletteSettingsAction(Palette palette, Func<Window> getMainWindow)
    {
        this.palette = palette;
        this.getMainWindow = getMainWindow;
    }

    public async void Execute(object? parameter)
    {
        await new SettingsForm(palette).ShowDialog(getMainWindow());
    }
    
    public bool CanExecute(object? parameter) => true;
}

public partial class MainWindow : Window
{
    private const int MenuSize = 32;
    private Menu? menu;

    public MainWindow() : this(CreateActions(), Services.GetImageController())
    {
        Services.SetMainWindow(this);
    }

    private static IUiAction[] CreateActions()
    {
        var imageController = Services.GetImageController();  
        var imageSettings = Services.GetImageSettings();
        var palette = Services.GetPalette();
        var getMainWindow = Services.GetMainWindow;

        return
        [
            new SaveImageAction(imageController, getMainWindow),
            new DragonFractalAction(),  
            new KochFractalAction(),
            new ImageSettingsAction(imageController, imageSettings, getMainWindow),
            new PaletteSettingsAction(palette, getMainWindow)
        ];
    }

    private void InitializeComponent()
    {
        AvaloniaXamlLoader.Load(this);
        menu = this.FindNameScope()?.Find<Menu>("Menu");
        this.FindNameScope()?.Find<ImageControl>("Image");
    }

    private MainWindow(IUiAction[] actions, IImageController imageController)
    {
        InitializeComponent();

        var imageSettings = CreateSettingsManager().Load().ImageSettings;
        ClientSize = new Size(imageSettings.Width, imageSettings.Height + MenuSize);
        menu!.ItemsSource = actions.ToMenuItems();
        Title = "Fractal Painter";
        imageController.RecreateImage(imageSettings);
    }

    private static SettingsManager CreateSettingsManager() =>
        new(new XmlObjectSerializer(), new FileBlobStorage());
}

