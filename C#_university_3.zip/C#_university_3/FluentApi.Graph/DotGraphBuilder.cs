﻿namespace FluentApi.Graph;

public enum NodeShape
{
    Box,
    Ellipse
}

public interface IGraphBuilder
{
    NodeLink AddNode(string name);
    EdgeLink AddEdge(string start, string destination);
    string Build();
}

public interface INodeAttributes
{
    INodeAttributes Color(string value);
    INodeAttributes FontSize(double value);
    INodeAttributes Label(string value);
    INodeAttributes Shape(NodeShape shape);
}

public interface IEdgeAttributes
{
    IEdgeAttributes Color(string value);
    IEdgeAttributes FontSize(double value);
    IEdgeAttributes Label(string value);
    IEdgeAttributes Weight(double value);
}

public static class NodeShapeExtensions
{
    public static string ToDot(this NodeShape shape)
    {
        return shape switch
        {
            NodeShape.Box => "box",
            NodeShape.Ellipse => "ellipse",
            _ => throw new ArgumentException(null, nameof(shape))
        };
    }
}

public static class DotGraphBuilder
{
    public static IGraphBuilder DirectedGraph(string graphName) =>
        new GraphBuilder(graphName, true, false);

    public static IGraphBuilder UndirectedGraph(string graphName) =>
        new GraphBuilder(graphName, false, false);
}

public class NodeLink : IGraphBuilder
{
    private readonly GraphBuilder builder;
    private readonly GraphNode node;

    public NodeLink(GraphBuilder builder, GraphNode node)
    {
        this.builder = builder;
        this.node = node;
    }

    public IGraphBuilder With(Action<INodeAttributes> configure)
    {
        if (configure != null)
            configure(new NodeAttributes(node));
        
        return builder;
    }

    public NodeLink AddNode(string name) => builder.AddNode(name);
    public EdgeLink AddEdge(string start, string destination) => builder.AddEdge(start, destination);
    public string Build() => builder.Build();
}

public class EdgeLink : IGraphBuilder
{
    private readonly GraphBuilder builder;
    private readonly GraphEdge edge;

    public EdgeLink(GraphBuilder builder, GraphEdge edge)
    {
        this.builder = builder;
        this.edge = edge;
    }

    public IGraphBuilder With(Action<IEdgeAttributes> configure)
    {
        if (configure != null)
            configure(new EdgeAttributes(edge));
        
        return builder;
    }

    public NodeLink AddNode(string name) => builder.AddNode(name);
    public EdgeLink AddEdge(string start, string destination) => builder.AddEdge(start, destination);
    public string Build() => builder.Build();
}

public class NodeAttributes : INodeAttributes
{
    private readonly GraphNode node;

    public NodeAttributes(GraphNode node)
    {
        this.node = node;
    }

    public INodeAttributes Color(string value)
    {
        Set("color", value); 
        return this;
    }

    public INodeAttributes FontSize(double value)
    {
        Set("fontsize", value.ToString(System.Globalization.CultureInfo.InvariantCulture)); 
        return this;
    }

    public INodeAttributes Label(string value)
    {
        Set("label", value); 
        return this;
    }

    public INodeAttributes Shape(NodeShape shape)
    {
        Set("shape", shape.ToDot()); 
        return this;
    }

    private void Set(string key, string value) => node.Attributes[key] = value;
}

public class EdgeAttributes : IEdgeAttributes
{
    private readonly GraphEdge edge;

    public EdgeAttributes(GraphEdge edge)
    {
        this.edge = edge;
    }

    public IEdgeAttributes Color(string value)
    {
        Set("color", value); 
        return this;
    }

    public IEdgeAttributes FontSize(double value)
    {
        Set("fontsize", value.ToString(System.Globalization.CultureInfo.InvariantCulture)); 
        return this;
    }

    public IEdgeAttributes Label(string value)
    {
        Set("label", value); 
        return this;
    }

    public IEdgeAttributes Weight(double value)
    {
        Set("weight", value.ToString(System.Globalization.CultureInfo.InvariantCulture)); 
        return this;
    }

    private void Set(string key, string value) => edge.Attributes[key] = value;
}

public class GraphBuilder : IGraphBuilder
{
    private readonly Graph graph;

    public GraphBuilder(string name, bool directed, bool strict)
    {
        graph = new Graph(name, directed, strict);
    }

    public NodeLink AddNode(string name)
    {
        var node = graph.AddNode(name);
        return new NodeLink(this, node);
    }

    public EdgeLink AddEdge(string start, string destination)
    {
        var edge = graph.AddEdge(start, destination);
        return new EdgeLink(this, edge);
    }

    public string Build() => graph.ToDotFormat();
}