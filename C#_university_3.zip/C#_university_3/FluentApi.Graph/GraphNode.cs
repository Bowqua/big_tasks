﻿namespace FluentApi.Graph;

public partial class GraphNode
{
	public readonly Dictionary<string, string> Attributes = new();
	public string Name { get; }

	public GraphNode(string name)
	{
		Name = name;
	}
}