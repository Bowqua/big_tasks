﻿using System.Collections;

namespace Generics.BinaryTrees;

public class BinaryTree<T> : IEnumerable<T>
{
    public BinaryTree<T>? Left { get; private set; }
    public BinaryTree<T>? Right { get; private set; }
    public T Value
    {
        get
        {
            if (!hasValue)
                throw new InvalidOperationException();
            
            return value;
        }
    }
    
    private bool hasValue;
    private T value;
    private int count;

    public bool Add(T element)
    {
        if (!hasValue)
        {
            value = element;
            hasValue = true;
            count++;
            
            return true;
        }
        
        var compare = Comparer<T>.Default.Compare(element, value);
        if (compare <= 0)
        {
            if (Left == null)
                Left = new BinaryTree<T>();
            
            Left.Add(element);
            count++;
            
            return true;
        }
        
        if (compare > 0)
        {
            if (Right == null)
                Right = new BinaryTree<T>();
            
            Right.Add(element);
            count++;
            
            return true;
        }
        
        return false;
    }

    public IEnumerator<T> GetEnumerator()
    {
        if (!hasValue)
           yield break;
        
        if (Left != null)
            foreach (var element in Left)
                yield return element;
        
        yield return value;
        
        if (Right != null) 
            foreach (var element in Right)
                yield return element;
    }

    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}

public static class BinaryTree
{
    public static BinaryTree<T> Create<T>(params T[] elements)
    {
        var tree = new BinaryTree<T>();
        foreach (var element in elements)
            tree.Add(element);
        
        return tree;
    }
}

